<?php

namespace App\Models\conferenceSponser;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class conferenceSponser extends Model
{
    use HasFactory;
}
